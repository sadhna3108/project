 <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <!-- Footer Area -->
                            <footer class="footer-area d-sm-flex justify-content-center align-items-center justify-content-between">
                                <!-- Copywrite Text -->
                                <div class="copywrite-text">
                                    <p>Created by @<a href="<?php echo base_url();?>assets/#">Antina</a></p>
                                </div>
                                <div class="fotter-icon text-center">
                                    <a href="<?php echo base_url();?>assets/#" class="action-item mr-2" data-toggle="tooltip" title="Facebook">
                                        <i class="fa fa-facebook" aria-hidden="true"></i>
                                    </a>
                                    <a href="<?php echo base_url();?>assets/#" class="action-item mr-2" data-toggle="tooltip" title="Twitter">
                                        <i class="fa fa-twitter" aria-hidden="true"></i>
                                    </a>
                                    <a href="<?php echo base_url();?>assets/#" class="action-item mr-2" data-toggle="tooltip" title="Pinterest">
                                        <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                                    </a>
                                    <a href="<?php echo base_url();?>assets/#" class="action-item mr-2" data-toggle="tooltip" title="Instagram">
                                        <i class="fa fa-instagram" aria-hidden="true"></i>
                                    </a>
                                </div>
                            </footer>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ======================================
    ********* Page Wrapper Area End ***********
    ======================================= -->

    <!-- Must needed plugins to the run this Template -->
    <script src="<?php echo base_url();?>assets/js/core.js"></script>
    <script src="<?php echo base_url();?>assets/js/bundle.js"></script>

    <!-- These plugins only need for the run this page -->
    <script src="<?php echo base_url();?>assets/js/default-assets/mini-event-calendar.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/default-assets/apexchart.min.js"></script>

    <!-- Inject JS -->
    <script src="<?php echo base_url();?>assets/js/default-assets/setting.js"></script>
    <script src="<?php echo base_url();?>assets/js/default-assets/active.js"></script>

    <!-- Custom js for this page -->
    <script src="<?php echo base_url();?>assets/js/default-assets/mini-calendar-active.js"></script>
    <script src="<?php echo base_url();?>assets/js/default-assets/dashboard-active.js"></script>

</body>


<!-- Mirrored from demo.riktheme.com/antina/side-menu/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 09 Jul 2020 09:17:27 GMT -->
</html>